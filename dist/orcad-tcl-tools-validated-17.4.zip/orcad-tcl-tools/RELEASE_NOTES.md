# Release Notes — Capture 兼容性修复与工具更新

[English](RELEASE_NOTES.en.md) · [安装](install.md) · [使用说明](usage.md)

发布日期：2026-10-10。本文对应本次兼容性更新；运行脚本内部版本号仍为 1.0.0。

## 菜单、加载与编码修复

- 使用 Capture 支持的 Tcl 列表参数调用 InsertXMLMenu，并通过 RegisterAction 注册执行与更新回调，替代错误的 XML 文件路径调用。
- GUI 和消息框在调用 winfo 等 Tk 命令前按需加载 Tk；初始化失败时提供明确诊断。
- 隐藏工具初始化产生的空白 Tk 根窗口，保留已存在的第三方 Tk 界面。
- 使用显式 UTF-8 脚本加载与 ASCII 自动加载引导；英文菜单标签避开原生菜单中文代码页差异，移除面板按钮上的不兼容图形符号。
- 菜单注册可重试，已成功注册的项目不重复添加；原快捷命令保留。
- 修正 Capture Session、设计、选择对象、页面和元件遍历、CString 属性读取、属性写入及显示文字创建接口。

## ShowProperties

- 电阻显示封装；电容同时选择默认两项时显示组合标签，例如 CC0805/6.3V。
- 缺少 VOLTAGE_RATING 时，从电容 Description 提取单一明确电压；保留已有耐压值，跳过缺失或冲突描述。
- 保留源属性数据，组合标签存为 CAP_PACKAGE_VOLTAGE；隐藏原独立封装/耐压文字。
- 新标签沿用已有 Value/Reference 的字体、旋转及坐标锚点。提供 RepositionProperties 修正已生成文字的位置与间隔。

## BulkReplace 与 DNP

- BulkReplace 增加 PCB Footprint 模式，与 Value、Part Number 共用精确匹配扫描和属性替换流程。
- 修复全设计扫描及页面名称读取；修正替换成功日志；单个写入失败记录后继续。
- DNP 修复全设计扫描，支持非空多字符前缀；重复标记不叠加前缀，取消恢复原值。
- 实验性 CIS 完整换料入口及诊断文件已移除。BulkReplace 仍只替换指定属性，不同步数据库，不进行完整符号换料。

## 验证结果

实机基准：**OrCAD Capture CIS 17.4-2019 S037（4108587），Windows SPB 64-bit Edition，Tcl 8.6.5**。

- 已验证手动加载、中文面板、ShowProperties 封装与电压组合显示和定位。
- 已验证 Part Number 扫描与结果列表。
- 已验证 DNP 批量标记、批量取消和全设计扫描。
- 11 项 Tcl 模拟回归测试通过；发布包编码、内容和本地文档链接检查通过。

原反馈涉及 **17.2-2016 S079 / S083**。本次修复针对其菜单、Tk 和编码问题，但尚未在这两个补丁版本实机复测。不能据此宣称 17.2 已完全兼容。其他产品候选见 README。

## 升级与限制

关闭面板，替换全部运行脚本并重新加载入口，或重新启动 Capture。自动加载采用单一 ASCII 引导文件与工具子目录，见安装手册。不要混用旧脚本及不同编码。

已有错误位置通过 RepositionProperties 显式修正；更新不自动移动所有设计文字。组合标签在源属性改变后需重新执行显示。

文字排版不检测元件、连线碰撞；Occurrence 覆盖值需另外核对。Undo、实际批量替换写入、CSV 导出、菜单点击及自动加载仍需完整实机验收。CSV 使用简单逗号分隔。DNP 不自动管理 CIS Variant 或 BOM 排除。

## 文档

更新中英文 README、安装手册和使用说明，补充完整操作步骤、示例、故障排查及版本验证范围。发布包可在仓库 Releases 下载。
